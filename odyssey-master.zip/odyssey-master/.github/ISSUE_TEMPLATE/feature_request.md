---
name: Feature request
about: Template to propose a new feature
title: ''
labels: ''
assignees: ''

---

# Feature request

<!-- Add your feature request here. Please describe your proposal as accurate as possible. -->
