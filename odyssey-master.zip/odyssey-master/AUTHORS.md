# Contributors

- Hendrik Borghorst - Team Gateship One
- Frederik Lütkes - Team Gateship One
- Alessandra Ghiazza - Italian Translation
- Kévin Minions - French Translation
- mray (GitHub user) - Image tweaks
- Daria Szatan & Paweł Wojtczak - Polish Translation
- Dennis Guse - Optional private notification
- zeritti - Czech Translation
- Harry van der Wolf - Dutch Translation
- HafitzSetya - Indonesian Translation

and more, see: [Contributors](https://github.com/gateship-one/odyssey/graphs/contributors)

Also a big thanks to all people contributing on Github.
